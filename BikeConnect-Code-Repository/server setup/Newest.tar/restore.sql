--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bikeconnect;
--
-- Name: bikeconnect; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bikeconnect WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE bikeconnect OWNER TO postgres;

\connect bikeconnect

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ADMINSESSIONS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ADMINSESSIONS" (
    "TOKEN" character(32) NOT NULL,
    "EID" integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public."ADMINSESSIONS" OWNER TO postgres;

--
-- Name: BB; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BB" (
    "BOID" integer NOT NULL,
    "BID" integer NOT NULL
);


ALTER TABLE public."BB" OWNER TO postgres;

--
-- Name: BB_BID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BB_BID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BB_BID_seq" OWNER TO postgres;

--
-- Name: BB_BID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BB_BID_seq" OWNED BY public."BB"."BID";


--
-- Name: BB_BOID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BB_BOID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BB_BOID_seq" OWNER TO postgres;

--
-- Name: BB_BOID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BB_BOID_seq" OWNED BY public."BB"."BOID";


--
-- Name: BIKEHUB; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BIKEHUB" (
    "HID" integer NOT NULL,
    "HNAME" character(32) NOT NULL,
    "BCAPACITY" integer NOT NULL,
    "LATITUDE" double precision NOT NULL,
    "LONGITUDE" double precision NOT NULL
);


ALTER TABLE public."BIKEHUB" OWNER TO postgres;

--
-- Name: BIKES; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BIKES" (
    "BID" integer NOT NULL,
    "BTYPE" character(32),
    "STATUS" character(32),
    "VID" integer NOT NULL,
    "HID" integer NOT NULL,
    "LATITUDE" double precision,
    "LONGITUDE" double precision
);


ALTER TABLE public."BIKES" OWNER TO postgres;

--
-- Name: BIKEHUBVIEW; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."BIKEHUBVIEW" AS
 SELECT "BIKES"."HID",
    "BIKEHUB"."HNAME",
    "BIKEHUB"."BCAPACITY",
    "BIKES"."BID",
    "BIKES"."BTYPE",
    "BIKES"."STATUS",
    "BIKEHUB"."LATITUDE",
    "BIKEHUB"."LONGITUDE"
   FROM (public."BIKES"
     JOIN public."BIKEHUB" USING ("HID"));


ALTER TABLE public."BIKEHUBVIEW" OWNER TO postgres;

--
-- Name: BIKEHUB_HID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BIKEHUB_HID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BIKEHUB_HID_seq" OWNER TO postgres;

--
-- Name: BIKEHUB_HID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BIKEHUB_HID_seq" OWNED BY public."BIKEHUB"."HID";


--
-- Name: BIKESTATUS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BIKESTATUS" (
    "STATUS" character(32) NOT NULL
);


ALTER TABLE public."BIKESTATUS" OWNER TO postgres;

--
-- Name: BIKES_BID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BIKES_BID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BIKES_BID_seq" OWNER TO postgres;

--
-- Name: BIKES_BID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BIKES_BID_seq" OWNED BY public."BIKES"."BID";


--
-- Name: BIKES_HID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BIKES_HID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BIKES_HID_seq" OWNER TO postgres;

--
-- Name: BIKES_HID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BIKES_HID_seq" OWNED BY public."BIKES"."HID";


--
-- Name: BIKES_VID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BIKES_VID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BIKES_VID_seq" OWNER TO postgres;

--
-- Name: BIKES_VID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BIKES_VID_seq" OWNED BY public."BIKES"."VID";


--
-- Name: BIKETYPES; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BIKETYPES" (
    "BTYPE" character(32) NOT NULL,
    "COST" integer NOT NULL
);


ALTER TABLE public."BIKETYPES" OWNER TO postgres;

--
-- Name: BOOKING; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BOOKING" (
    "BOID" integer NOT NULL,
    "USERNAME" character varying(32),
    "DATEFROM" timestamp with time zone NOT NULL,
    "DATETO" timestamp with time zone NOT NULL,
    "BOOKINGTYPE" character(32),
    "GEAR" boolean
);


ALTER TABLE public."BOOKING" OWNER TO postgres;

--
-- Name: BOOKINGTYPE; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BOOKINGTYPE" (
    "BTYPE" character(32) NOT NULL
);


ALTER TABLE public."BOOKINGTYPE" OWNER TO postgres;

--
-- Name: BOOKINGVIEW; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."BOOKINGVIEW" AS
 SELECT "BOOKING"."BOID",
    "BOOKING"."USERNAME",
    "BIKES"."HID",
    "BIKEHUB"."HNAME",
    "BOOKING"."DATEFROM",
    "BOOKING"."DATETO",
    "BOOKING"."BOOKINGTYPE",
    "BB"."BID",
    "BIKES"."BTYPE",
    "BIKETYPES"."COST",
    "BIKES"."LATITUDE",
    "BIKES"."LONGITUDE",
    "BOOKING"."GEAR"
   FROM ((((public."BOOKING"
     JOIN public."BB" USING ("BOID"))
     JOIN public."BIKES" USING ("BID"))
     JOIN public."BIKEHUB" USING ("HID"))
     JOIN public."BIKETYPES" USING ("BTYPE"));


ALTER TABLE public."BOOKINGVIEW" OWNER TO postgres;

--
-- Name: BOOKING_BOID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BOOKING_BOID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BOOKING_BOID_seq" OWNER TO postgres;

--
-- Name: BOOKING_BOID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BOOKING_BOID_seq" OWNED BY public."BOOKING"."BOID";


--
-- Name: COMPLAINTS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."COMPLAINTS" (
    "BOID" integer NOT NULL,
    "COMPLAINT" character varying(400)
);


ALTER TABLE public."COMPLAINTS" OWNER TO postgres;

--
-- Name: COMPLAINTSVIEW; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."COMPLAINTSVIEW" AS
 SELECT "BOOKING"."BOID",
    "BOOKING"."USERNAME",
    "BIKES"."HID",
    "BIKEHUB"."HNAME",
    "BOOKING"."DATEFROM",
    "BOOKING"."DATETO",
    "BOOKING"."BOOKINGTYPE",
    "BB"."BID",
    "BIKES"."BTYPE",
    "BIKETYPES"."COST",
    "BIKES"."LATITUDE",
    "BIKES"."LONGITUDE",
    "BOOKING"."GEAR",
    "COMPLAINTS"."COMPLAINT"
   FROM (((((public."BOOKING"
     JOIN public."BB" USING ("BOID"))
     JOIN public."BIKES" USING ("BID"))
     JOIN public."COMPLAINTS" USING ("BOID"))
     JOIN public."BIKEHUB" USING ("HID"))
     JOIN public."BIKETYPES" USING ("BTYPE"));


ALTER TABLE public."COMPLAINTSVIEW" OWNER TO postgres;

--
-- Name: COMPLAINTS_BOID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."COMPLAINTS_BOID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."COMPLAINTS_BOID_seq" OWNER TO postgres;

--
-- Name: COMPLAINTS_BOID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."COMPLAINTS_BOID_seq" OWNED BY public."COMPLAINTS"."BOID";


--
-- Name: USERS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."USERS" (
    "USERNAME" character varying(32) NOT NULL,
    "PASSWORD" character varying(32) NOT NULL,
    "NAME" character varying(32) NOT NULL,
    "EMAIL" character varying(32) NOT NULL
);


ALTER TABLE public."USERS" OWNER TO postgres;

--
-- Name: EMPLOYEES; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EMPLOYEES" (
    "EID" integer NOT NULL,
    "ADDRESS" character varying(128) NOT NULL
)
INHERITS (public."USERS");


ALTER TABLE public."EMPLOYEES" OWNER TO postgres;

--
-- Name: EWC; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EWC" (
    "EID" integer NOT NULL,
    "CID" integer NOT NULL
);


ALTER TABLE public."EWC" OWNER TO postgres;

--
-- Name: WORKCENTER; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WORKCENTER" (
    "CID" integer NOT NULL,
    "ADDRESS" character varying(128) NOT NULL
);


ALTER TABLE public."WORKCENTER" OWNER TO postgres;

--
-- Name: EMPLOYEESVIEWS; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."EMPLOYEESVIEWS" AS
 SELECT "EMPLOYEES"."USERNAME",
    "EMPLOYEES"."NAME",
    "EMPLOYEES"."EMAIL",
    "WORKCENTER"."CID",
    "WORKCENTER"."ADDRESS"
   FROM ((public."EMPLOYEES"
     JOIN public."EWC" USING ("EID"))
     JOIN public."WORKCENTER" USING ("CID"));


ALTER TABLE public."EMPLOYEESVIEWS" OWNER TO postgres;

--
-- Name: EMPLOYEES_EID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EMPLOYEES_EID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EMPLOYEES_EID_seq" OWNER TO postgres;

--
-- Name: EMPLOYEES_EID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EMPLOYEES_EID_seq" OWNED BY public."EMPLOYEES"."EID";


--
-- Name: EWC_CID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EWC_CID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EWC_CID_seq" OWNER TO postgres;

--
-- Name: EWC_CID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EWC_CID_seq" OWNED BY public."EWC"."CID";


--
-- Name: EWC_EID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EWC_EID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EWC_EID_seq" OWNER TO postgres;

--
-- Name: EWC_EID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EWC_EID_seq" OWNED BY public."EWC"."EID";


--
-- Name: SESSIONS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SESSIONS" (
    "TOKEN" character(32) NOT NULL,
    "USERNAME" character varying(32),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public."SESSIONS" OWNER TO postgres;

--
-- Name: VENDOR; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VENDOR" (
    "VID" integer NOT NULL,
    "NAME" character(32) NOT NULL,
    "ADDRESS" character varying(128) NOT NULL
);


ALTER TABLE public."VENDOR" OWNER TO postgres;

--
-- Name: VENDOR_VID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VENDOR_VID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."VENDOR_VID_seq" OWNER TO postgres;

--
-- Name: VENDOR_VID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VENDOR_VID_seq" OWNED BY public."VENDOR"."VID";


--
-- Name: WORKCENTER_CID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."WORKCENTER_CID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."WORKCENTER_CID_seq" OWNER TO postgres;

--
-- Name: WORKCENTER_CID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."WORKCENTER_CID_seq" OWNED BY public."WORKCENTER"."CID";


--
-- Name: BB BOID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BB" ALTER COLUMN "BOID" SET DEFAULT nextval('public."BB_BOID_seq"'::regclass);


--
-- Name: BB BID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BB" ALTER COLUMN "BID" SET DEFAULT nextval('public."BB_BID_seq"'::regclass);


--
-- Name: BIKEHUB HID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKEHUB" ALTER COLUMN "HID" SET DEFAULT nextval('public."BIKEHUB_HID_seq"'::regclass);


--
-- Name: BIKES BID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES" ALTER COLUMN "BID" SET DEFAULT nextval('public."BIKES_BID_seq"'::regclass);


--
-- Name: BIKES VID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES" ALTER COLUMN "VID" SET DEFAULT nextval('public."BIKES_VID_seq"'::regclass);


--
-- Name: BIKES HID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES" ALTER COLUMN "HID" SET DEFAULT nextval('public."BIKES_HID_seq"'::regclass);


--
-- Name: BOOKING BOID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BOOKING" ALTER COLUMN "BOID" SET DEFAULT nextval('public."BOOKING_BOID_seq"'::regclass);


--
-- Name: COMPLAINTS BOID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."COMPLAINTS" ALTER COLUMN "BOID" SET DEFAULT nextval('public."COMPLAINTS_BOID_seq"'::regclass);


--
-- Name: EMPLOYEES EID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EMPLOYEES" ALTER COLUMN "EID" SET DEFAULT nextval('public."EMPLOYEES_EID_seq"'::regclass);


--
-- Name: EWC EID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EWC" ALTER COLUMN "EID" SET DEFAULT nextval('public."EWC_EID_seq"'::regclass);


--
-- Name: EWC CID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EWC" ALTER COLUMN "CID" SET DEFAULT nextval('public."EWC_CID_seq"'::regclass);


--
-- Name: VENDOR VID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VENDOR" ALTER COLUMN "VID" SET DEFAULT nextval('public."VENDOR_VID_seq"'::regclass);


--
-- Name: WORKCENTER CID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WORKCENTER" ALTER COLUMN "CID" SET DEFAULT nextval('public."WORKCENTER_CID_seq"'::regclass);


--
-- Data for Name: ADMINSESSIONS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ADMINSESSIONS" ("TOKEN", "EID", created_at) FROM stdin;
\.
COPY public."ADMINSESSIONS" ("TOKEN", "EID", created_at) FROM '$$PATH$$/2309.dat';

--
-- Data for Name: BB; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BB" ("BOID", "BID") FROM stdin;
\.
COPY public."BB" ("BOID", "BID") FROM '$$PATH$$/2310.dat';

--
-- Data for Name: BIKEHUB; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BIKEHUB" ("HID", "HNAME", "BCAPACITY", "LATITUDE", "LONGITUDE") FROM stdin;
\.
COPY public."BIKEHUB" ("HID", "HNAME", "BCAPACITY", "LATITUDE", "LONGITUDE") FROM '$$PATH$$/2313.dat';

--
-- Data for Name: BIKES; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BIKES" ("BID", "BTYPE", "STATUS", "VID", "HID", "LATITUDE", "LONGITUDE") FROM stdin;
\.
COPY public."BIKES" ("BID", "BTYPE", "STATUS", "VID", "HID", "LATITUDE", "LONGITUDE") FROM '$$PATH$$/2314.dat';

--
-- Data for Name: BIKESTATUS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BIKESTATUS" ("STATUS") FROM stdin;
\.
COPY public."BIKESTATUS" ("STATUS") FROM '$$PATH$$/2316.dat';

--
-- Data for Name: BIKETYPES; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BIKETYPES" ("BTYPE", "COST") FROM stdin;
\.
COPY public."BIKETYPES" ("BTYPE", "COST") FROM '$$PATH$$/2320.dat';

--
-- Data for Name: BOOKING; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BOOKING" ("BOID", "USERNAME", "DATEFROM", "DATETO", "BOOKINGTYPE", "GEAR") FROM stdin;
\.
COPY public."BOOKING" ("BOID", "USERNAME", "DATEFROM", "DATETO", "BOOKINGTYPE", "GEAR") FROM '$$PATH$$/2321.dat';

--
-- Data for Name: BOOKINGTYPE; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BOOKINGTYPE" ("BTYPE") FROM stdin;
\.
COPY public."BOOKINGTYPE" ("BTYPE") FROM '$$PATH$$/2322.dat';

--
-- Data for Name: COMPLAINTS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."COMPLAINTS" ("BOID", "COMPLAINT") FROM stdin;
\.
COPY public."COMPLAINTS" ("BOID", "COMPLAINT") FROM '$$PATH$$/2324.dat';

--
-- Data for Name: EMPLOYEES; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EMPLOYEES" ("USERNAME", "PASSWORD", "NAME", "EMAIL", "EID", "ADDRESS") FROM stdin;
\.
COPY public."EMPLOYEES" ("USERNAME", "PASSWORD", "NAME", "EMAIL", "EID", "ADDRESS") FROM '$$PATH$$/2327.dat';

--
-- Data for Name: EWC; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EWC" ("EID", "CID") FROM stdin;
\.
COPY public."EWC" ("EID", "CID") FROM '$$PATH$$/2328.dat';

--
-- Data for Name: SESSIONS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SESSIONS" ("TOKEN", "USERNAME", created_at) FROM stdin;
\.
COPY public."SESSIONS" ("TOKEN", "USERNAME", created_at) FROM '$$PATH$$/2333.dat';

--
-- Data for Name: USERS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."USERS" ("USERNAME", "PASSWORD", "NAME", "EMAIL") FROM stdin;
\.
COPY public."USERS" ("USERNAME", "PASSWORD", "NAME", "EMAIL") FROM '$$PATH$$/2326.dat';

--
-- Data for Name: VENDOR; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VENDOR" ("VID", "NAME", "ADDRESS") FROM stdin;
\.
COPY public."VENDOR" ("VID", "NAME", "ADDRESS") FROM '$$PATH$$/2334.dat';

--
-- Data for Name: WORKCENTER; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WORKCENTER" ("CID", "ADDRESS") FROM stdin;
\.
COPY public."WORKCENTER" ("CID", "ADDRESS") FROM '$$PATH$$/2329.dat';

--
-- Name: BB_BID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BB_BID_seq"', 1, false);


--
-- Name: BB_BOID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BB_BOID_seq"', 1, false);


--
-- Name: BIKEHUB_HID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BIKEHUB_HID_seq"', 5, true);


--
-- Name: BIKES_BID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BIKES_BID_seq"', 177, true);


--
-- Name: BIKES_HID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BIKES_HID_seq"', 1, false);


--
-- Name: BIKES_VID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BIKES_VID_seq"', 1, false);


--
-- Name: BOOKING_BOID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BOOKING_BOID_seq"', 1, false);


--
-- Name: COMPLAINTS_BOID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."COMPLAINTS_BOID_seq"', 1, false);


--
-- Name: EMPLOYEES_EID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EMPLOYEES_EID_seq"', 1, false);


--
-- Name: EWC_CID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EWC_CID_seq"', 1, false);


--
-- Name: EWC_EID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EWC_EID_seq"', 1, false);


--
-- Name: VENDOR_VID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VENDOR_VID_seq"', 1, false);


--
-- Name: WORKCENTER_CID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WORKCENTER_CID_seq"', 1, false);


--
-- Name: ADMINSESSIONS ADMINSESSIONS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ADMINSESSIONS"
    ADD CONSTRAINT "ADMINSESSIONS_pkey" PRIMARY KEY ("TOKEN");


--
-- Name: BB BB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BB"
    ADD CONSTRAINT "BB_pkey" PRIMARY KEY ("BOID", "BID");


--
-- Name: BIKEHUB BIKEHUB_HNAME_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKEHUB"
    ADD CONSTRAINT "BIKEHUB_HNAME_key" UNIQUE ("HNAME");


--
-- Name: BIKEHUB BIKEHUB_LATITUDE_LONGITUDE_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKEHUB"
    ADD CONSTRAINT "BIKEHUB_LATITUDE_LONGITUDE_key" UNIQUE ("LATITUDE", "LONGITUDE");


--
-- Name: BIKEHUB BIKEHUB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKEHUB"
    ADD CONSTRAINT "BIKEHUB_pkey" PRIMARY KEY ("HID");


--
-- Name: BIKESTATUS BIKESTATUS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKESTATUS"
    ADD CONSTRAINT "BIKESTATUS_pkey" PRIMARY KEY ("STATUS");


--
-- Name: BIKES BIKES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES"
    ADD CONSTRAINT "BIKES_pkey" PRIMARY KEY ("BID");


--
-- Name: BIKETYPES BIKETYPES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKETYPES"
    ADD CONSTRAINT "BIKETYPES_pkey" PRIMARY KEY ("BTYPE");


--
-- Name: BOOKINGTYPE BOOKINGTYPE_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BOOKINGTYPE"
    ADD CONSTRAINT "BOOKINGTYPE_pkey" PRIMARY KEY ("BTYPE");


--
-- Name: BOOKING BOOKING_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BOOKING"
    ADD CONSTRAINT "BOOKING_pkey" PRIMARY KEY ("BOID");


--
-- Name: EMPLOYEES EMPLOYEES_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EMPLOYEES"
    ADD CONSTRAINT "EMPLOYEES_pkey" PRIMARY KEY ("EID");


--
-- Name: EWC EWC_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EWC"
    ADD CONSTRAINT "EWC_pkey" PRIMARY KEY ("EID", "CID");


--
-- Name: SESSIONS SESSIONS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SESSIONS"
    ADD CONSTRAINT "SESSIONS_pkey" PRIMARY KEY ("TOKEN");


--
-- Name: USERS USERS_EMAIL_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."USERS"
    ADD CONSTRAINT "USERS_EMAIL_key" UNIQUE ("EMAIL");


--
-- Name: USERS USERS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."USERS"
    ADD CONSTRAINT "USERS_pkey" PRIMARY KEY ("USERNAME");


--
-- Name: VENDOR VENDOR_NAME_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VENDOR"
    ADD CONSTRAINT "VENDOR_NAME_key" UNIQUE ("NAME");


--
-- Name: VENDOR VENDOR_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VENDOR"
    ADD CONSTRAINT "VENDOR_pkey" PRIMARY KEY ("VID");


--
-- Name: WORKCENTER WORKCENTER_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WORKCENTER"
    ADD CONSTRAINT "WORKCENTER_pkey" PRIMARY KEY ("CID");


--
-- Name: ADMINSESSIONS ADMINSESSIONS_EID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ADMINSESSIONS"
    ADD CONSTRAINT "ADMINSESSIONS_EID_fkey" FOREIGN KEY ("EID") REFERENCES public."EMPLOYEES"("EID");


--
-- Name: BB BB_BID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BB"
    ADD CONSTRAINT "BB_BID_fkey" FOREIGN KEY ("BID") REFERENCES public."BIKES"("BID");


--
-- Name: BB BB_BOID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BB"
    ADD CONSTRAINT "BB_BOID_fkey" FOREIGN KEY ("BOID") REFERENCES public."BOOKING"("BOID");


--
-- Name: BIKES BIKES_BTYPE_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES"
    ADD CONSTRAINT "BIKES_BTYPE_fkey" FOREIGN KEY ("BTYPE") REFERENCES public."BIKETYPES"("BTYPE");


--
-- Name: BIKES BIKES_HID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES"
    ADD CONSTRAINT "BIKES_HID_fkey" FOREIGN KEY ("HID") REFERENCES public."BIKEHUB"("HID");


--
-- Name: BIKES BIKES_STATUS_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES"
    ADD CONSTRAINT "BIKES_STATUS_fkey" FOREIGN KEY ("STATUS") REFERENCES public."BIKESTATUS"("STATUS");


--
-- Name: BIKES BIKES_VID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BIKES"
    ADD CONSTRAINT "BIKES_VID_fkey" FOREIGN KEY ("VID") REFERENCES public."VENDOR"("VID");


--
-- Name: BOOKING BOOKING_BOOKINGTYPE_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BOOKING"
    ADD CONSTRAINT "BOOKING_BOOKINGTYPE_fkey" FOREIGN KEY ("BOOKINGTYPE") REFERENCES public."BOOKINGTYPE"("BTYPE");


--
-- Name: BOOKING BOOKING_USERNAME_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BOOKING"
    ADD CONSTRAINT "BOOKING_USERNAME_fkey" FOREIGN KEY ("USERNAME") REFERENCES public."USERS"("USERNAME");


--
-- Name: COMPLAINTS COMPLAINTS_BOID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."COMPLAINTS"
    ADD CONSTRAINT "COMPLAINTS_BOID_fkey" FOREIGN KEY ("BOID") REFERENCES public."BOOKING"("BOID");


--
-- Name: EWC EWC_CID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EWC"
    ADD CONSTRAINT "EWC_CID_fkey" FOREIGN KEY ("CID") REFERENCES public."WORKCENTER"("CID");


--
-- Name: EWC EWC_EID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EWC"
    ADD CONSTRAINT "EWC_EID_fkey" FOREIGN KEY ("EID") REFERENCES public."EMPLOYEES"("EID");


--
-- Name: SESSIONS SESSIONS_USERNAME_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SESSIONS"
    ADD CONSTRAINT "SESSIONS_USERNAME_fkey" FOREIGN KEY ("USERNAME") REFERENCES public."USERS"("USERNAME");


--
-- PostgreSQL database dump complete
--

